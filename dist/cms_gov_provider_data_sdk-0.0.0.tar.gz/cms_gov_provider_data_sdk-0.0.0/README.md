# cms-gov-provider-data-sdk

[![test](github.com/davebelais/cms-gov-provider-data-sdk/actions/workflows/test.yml/badge.svg?branch=main)](github.com/davebelais/cms-gov-provider-data-sdk/actions/workflows/test.yml)
[![PyPI version](https://badge.fury.io/py/cms-gov-provider-data-sdk.svg?icon=si%3Apython)](https://badge.fury.io/py/cms-gov-provider-data-sdk)

Please refer to the [documentation](https://davebelais.github.io/cms-gov-provider-data-sdk) for
detailed usage information.

## Install

You can install this package from PYPI using any package manager:

```bash
pip3 install cms-gov-provider-data-sdk
```

## Introduction

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
incididunt ut labore et dolore magna aliqua. Cras pulvinar mattis nunc sed.
Montes nascetur ridiculus mus mauris vitae ultricies leo integer. Purus ut
faucibus pulvinar elementum integer.
